from __future__ import annotations

import re

from .base_agent import BaseTeamAgent, AgentState, _utcnow
from ...core.models import AgentLoadOut
from ...tools.registry import ToolRegistry
from ...tools.scope_checker import validate_scope, ScopeViolationError
import httpx


class WebTester(BaseTeamAgent):
    agent_id    = "WebTester"
    model_alias = "MODEL_AGENT_STD"

    async def _execute_node(self, state: AgentState) -> dict:
        loadout   = AgentLoadOut(**state["loadout"])
        test_idx  = state.get("test_idx", 0)
        iteration = state.get("iteration", 0)
        scope_rules = state.get("scope_rules", {})

        if test_idx >= len(loadout.test_cases) or iteration >= loadout.max_iterations:
            return {"messages": [{"role": "system", "content": "[WebTester] done",
                                  "agent": self.agent_id, "ts": _utcnow()}]}

        tc      = loadout.test_cases[test_idx]
        surface = tc.get("surface", "")

        try:
            validate_scope(surface, scope_rules)
        except ScopeViolationError:
            return {
                "test_idx":  test_idx + 1,
                "iteration": iteration + 1,
                "messages":  [{"role": "system",
                               "content": f"[WebTester] scope skip: {surface}",
                               "agent": self.agent_id, "ts": _utcnow()}],
            }

        technique   = tc.get("technique", "")
        tool_config = loadout.tool_configs.get(technique, {})

        result = await self._run_web_technique(technique, surface, tool_config, tc, loadout, state)

        # Capture annotated screenshot evidence when a vulnerability is confirmed
        if result.get("confirmed"):
            result = await self._attach_screenshot_evidence(result, surface)

        findings = list(state.get("local_findings", []))
        if result.get("confirmed") or result.get("output"):
            from .base_agent import _build_raw_finding
            findings.append(_build_raw_finding(tc, result, self.agent_id))

        should_collab = len(findings) > 0 and iteration > 0 and iteration % 3 == 0

        return {
            "local_findings": findings,
            "test_idx":       test_idx + 1,
            "iteration":      iteration + 1,
            "_should_collaborate": should_collab,
            "messages": [{
                "role":    "system",
                "content": f"[WebTester] {technique} on {surface} → {'✓' if result.get('confirmed') else '·'}",
                "agent":   self.agent_id,
                "ts":      _utcnow(),
            }],
        }

    async def _run_web_technique(
        self,
        technique: str,
        surface: str,
        config: dict,
        tc: dict,
        loadout: "AgentLoadOut",
        state: "AgentState",
    ) -> dict:
        try:
            tool_fn = ToolRegistry.get(technique)
            return await tool_fn(target=surface, **config)
        except KeyError:
            pass

        if technique in ("xss_reflected", "xss"):
            # Layer 1: fast HTTPX reflected check
            result = await self._test_xss(surface, config)
            if not result.get("confirmed"):
                # Layer 2: DOM-based XSS — requires JS rendering via agent-browser
                result = await self._test_dom_xss(surface, config)
            return result

        if technique in ("csrf", "csrf_check"):
            return await self._test_csrf(surface, config)

        if technique in ("open_redirect",):
            # Layer 1: HTTP-level redirect (HTTPX)
            result = await self._test_open_redirect(surface, config)
            if not result.get("confirmed"):
                # Layer 2: JS-based redirect — only detectable with a real browser
                result = await self._test_js_open_redirect(surface, config)
            return result

        if technique in ("parameter_pollution", "http_param_pollution"):
            return await self._test_param_pollution(surface, config)

        if technique in ("storage_exposure", "localstorage_scan"):
            return await self._test_storage_exposure(surface, config)

        return await self._llm_execute(tc, loadout, state)

    # ── Layer 1 tests (HTTPX — fast, no JS) ──────────────────────────────────

    async def _test_xss(self, url: str, config: dict) -> dict:
        """Reflected XSS: check if payloads appear unencoded in the HTTP response."""
        payloads = [
            '<script>alert(1)</script>',
            '"><script>alert(1)</script>',
            "';alert(1)//",
            '<img src=x onerror=alert(1)>',
            '{{7*7}}',
            '${7*7}',
        ]
        try:
            async with httpx.AsyncClient(timeout=8, verify=False, follow_redirects=True) as client:
                for payload in payloads[:3]:
                    params = {config.get("field", "q"): payload}
                    resp = await client.get(url, params=params,
                                            headers={"User-Agent": "Mozilla/5.0 BountyMind/4.0"})
                    if payload in resp.text:
                        return {
                            "confirmed":  True,
                            "payload":    payload,
                            "output":     f"XSS payload reflected in response: {payload}",
                            "request":    {"url": url, "params": params},
                            "response_diff": {"reflected": payload},
                            "description": (
                                f"Reflected XSS at {url} via parameter '{config.get('field', 'q')}'. "
                                "Payload appears unencoded in the HTTP response body."
                            ),
                            "reproduction_steps": [
                                f"1. Navigate to {url}",
                                f"2. Set parameter {config.get('field','q')}={payload}",
                                "3. Observe payload reflected in HTML response without encoding",
                            ],
                        }
        except Exception:
            pass
        return {"confirmed": False, "output": ""}

    async def _test_csrf(self, url: str, config: dict) -> dict:
        try:
            async with httpx.AsyncClient(timeout=8, verify=False, follow_redirects=True) as client:
                resp = await client.get(url, headers={"User-Agent": "Mozilla/5.0 BountyMind/4.0"})
                html = resp.text
                has_csrf_token = bool(re.search(
                    r'(?:csrf|_token|authenticity_token|__RequestVerificationToken)',
                    html, re.I,
                ))
                has_form = bool(re.search(r'<form', html, re.I))
                if has_form and not has_csrf_token:
                    return {
                        "confirmed":   True,
                        "output":      f"Form at {url} lacks CSRF token",
                        "description": f"CSRF vulnerability: form at {url} has no anti-CSRF token",
                        "request":     {"url": url, "method": "GET"},
                        "response_diff": {"missing": "csrf_token"},
                        "payload":     "",
                        "reproduction_steps": [
                            f"1. Observe form at {url}",
                            "2. Note absence of CSRF token in form fields",
                            "3. Craft cross-origin POST request",
                            "4. Submit from attacker-controlled origin",
                        ],
                    }
        except Exception:
            pass
        return {"confirmed": False, "output": ""}

    async def _test_open_redirect(self, url: str, config: dict) -> dict:
        """Detect HTTP-level open redirects (3xx Location header)."""
        redirect_params = ["redirect", "return", "next", "url", "goto",
                           "redir", "redirect_uri", "redirect_url"]
        evil_url = "https://evil.example.com"
        try:
            async with httpx.AsyncClient(timeout=8, verify=False, follow_redirects=False) as client:
                for param in redirect_params:
                    test_url = f"{url}?{param}={evil_url}"
                    resp = await client.get(test_url,
                                            headers={"User-Agent": "Mozilla/5.0 BountyMind/4.0"})
                    if resp.status_code in (301, 302, 303, 307, 308):
                        location = resp.headers.get("location", "")
                        if "evil.example.com" in location:
                            return {
                                "confirmed":   True,
                                "payload":     evil_url,
                                "output":      f"Open redirect via '{param}' → {location}",
                                "description": f"Open redirect at {url} via parameter '{param}'",
                                "request":     {"url": test_url},
                                "response_diff": {"location": location},
                                "reproduction_steps": [
                                    f"1. Navigate to {test_url}",
                                    f"2. Observe redirect to {location}",
                                    "3. Attacker can redirect victims to phishing sites",
                                ],
                            }
        except Exception:
            pass
        return {"confirmed": False, "output": ""}

    async def _test_param_pollution(self, url: str, config: dict) -> dict:
        try:
            async with httpx.AsyncClient(timeout=8, verify=False, follow_redirects=True) as client:
                param = config.get("field", "id")
                resp1 = await client.get(f"{url}?{param}=1",
                                         headers={"User-Agent": "Mozilla/5.0 BountyMind/4.0"})
                resp2 = await client.get(f"{url}?{param}=1&{param}=2",
                                         headers={"User-Agent": "Mozilla/5.0 BountyMind/4.0"})
                if resp1.status_code != resp2.status_code or resp1.text[:200] != resp2.text[:200]:
                    return {
                        "confirmed":   True,
                        "output":      f"HTTP Parameter Pollution detected at {url} via {param}",
                        "description": f"Duplicate parameter '{param}' causes different behavior",
                        "request":     {"url": url, "params": f"{param}=1&{param}=2"},
                        "response_diff": {"status_change": resp1.status_code != resp2.status_code},
                        "payload":     f"{param}=1&{param}=2",
                        "reproduction_steps": [
                            f"1. Send {url}?{param}=1",
                            f"2. Send {url}?{param}=1&{param}=2",
                            "3. Compare responses",
                        ],
                    }
        except Exception:
            pass
        return {"confirmed": False, "output": ""}

    # ── Layer 2 tests (agent-browser — JS rendering required) ────────────────

    async def _test_dom_xss(self, url: str, config: dict) -> dict:
        """DOM-based XSS: inject payloads into rendered inputs and check for dialog execution.

        HTTPX-based tests miss DOM XSS because the payload executes only in the
        JS engine, not in the HTTP response. agent-browser:
        1. Renders the page (Chrome DevTools Protocol)
        2. Fills each input field with XSS payloads
        3. Uses `dialog status` to detect if alert() actually fired — the only
           reliable confirmation that JS executed
        """
        from ...tools.web.agent_browser_tool import (
            ab_open, ab_snapshot, ab_fill, ab_press, ab_close,
            ab_dialog_status, ab_dialog_accept,
            new_session_id, find_input_refs, is_available,
        )
        if not await is_available():
            return {"confirmed": False, "output": "agent-browser not available for DOM XSS"}

        # Payloads ordered: event-based first (most reliable DOM XSS detection),
        # then template injection, then script tag (often blocked by CSP)
        dom_payloads = [
            '<img src=x onerror=alert(1)>',
            '<svg onload=alert(1)>',
            '{{7*7}}',
            '${7*7}',
            '"><img src=x onerror=alert(1)>',
        ]
        session = new_session_id("domxss")
        try:
            snapshot = await ab_open(url, session, wait_networkidle=True)
            input_refs = find_input_refs(snapshot)

            for ref_info in input_refs[:3]:
                for payload in dom_payloads:
                    try:
                        await ab_fill(ref_info["ref"], payload, session)
                        # Submit via Enter to trigger any onChange/onSubmit handlers
                        await ab_press("Enter", session)

                        # Check if a JS dialog (alert) appeared — definitive XSS confirmation
                        dialog = await ab_dialog_status(session)
                        if "open" in dialog.lower():
                            await ab_dialog_accept(session)
                            return {
                                "confirmed":   True,
                                "payload":     payload,
                                "output":      (
                                    f"DOM XSS confirmed: alert() dialog fired via "
                                    f"'{ref_info['text']}' ({ref_info['ref']})"
                                ),
                                "description": (
                                    f"DOM-based XSS at {url} — payload executed in JS engine. "
                                    f"Field: '{ref_info['text']}'. Dialog status: {dialog}"
                                ),
                                "request":     {
                                    "url":     url,
                                    "ref":     ref_info["ref"],
                                    "field":   ref_info["text"],
                                    "payload": payload,
                                },
                                "response_diff": {"dialog_fired": True, "dialog_text": dialog},
                                "reproduction_steps": [
                                    f"1. Navigate to {url}",
                                    f"2. Locate input field '{ref_info['text']}'",
                                    f"3. Insert payload: {payload}",
                                    "4. Submit / trigger the field (press Enter)",
                                    "5. Observe alert() dialog — JS executed in DOM context",
                                ],
                            }

                        # Secondary check: payload visible in new snapshot (template injection)
                        new_snapshot = await ab_snapshot(session)
                        if "49" in new_snapshot and ("{{7*7}}" in payload or "${7*7}" in payload):
                            return {
                                "confirmed":   True,
                                "payload":     payload,
                                "output":      f"Template injection: 7*7=49 evaluated in DOM",
                                "description": f"Server-side/client-side template injection at {url}",
                                "request":     {"url": url, "ref": ref_info["ref"], "payload": payload},
                                "response_diff": {"evaluated": "49"},
                                "reproduction_steps": [
                                    f"1. Navigate to {url}",
                                    f"2. Insert `{payload}` into '{ref_info['text']}'",
                                    "3. Observe that 49 is rendered — template expression evaluated",
                                ],
                            }
                    except Exception:
                        continue
        except Exception:
            pass
        finally:
            await ab_close(session)

        return {"confirmed": False, "output": ""}

    async def _test_js_open_redirect(self, url: str, config: dict) -> dict:
        """Detect JS-based open redirects using agent-browser's `get url` command.

        Some apps redirect via window.location = param in JavaScript rather than
        HTTP 3xx headers. HTTPX with follow_redirects=False cannot detect these.
        agent-browser navigates the page fully and reports the final URL after
        all JS has executed.
        """
        from ...tools.web.agent_browser_tool import (
            ab_open, ab_get_url, ab_close, new_session_id, is_available,
        )
        if not await is_available():
            return {"confirmed": False, "output": "agent-browser not available for JS redirect"}

        redirect_params = ["redirect", "return", "next", "url", "goto",
                           "redir", "redirect_uri", "redirect_url"]
        evil_url = "https://evil.example.com"
        session  = new_session_id("jsredir")
        try:
            for param in redirect_params:
                test_url = f"{url}?{param}={evil_url}"
                try:
                    await ab_open(test_url, session, wait_networkidle=True)
                    final_url = await ab_get_url(session)
                    if "evil.example.com" in final_url:
                        return {
                            "confirmed":   True,
                            "payload":     evil_url,
                            "output":      f"JS open redirect via '{param}': final URL = {final_url}",
                            "description": (
                                f"JavaScript-based open redirect at {url} via parameter '{param}'. "
                                "Redirect triggered by client-side JS (not HTTP headers)."
                            ),
                            "request":     {"url": test_url},
                            "response_diff": {"final_url": final_url, "js_redirect": True},
                            "reproduction_steps": [
                                f"1. Navigate to {test_url}",
                                "2. Observe that JavaScript redirects to evil.example.com",
                                f"3. Final URL: {final_url}",
                                "4. Attacker can use this to redirect victims post-authentication",
                            ],
                        }
                except Exception:
                    continue
        except Exception:
            pass
        finally:
            await ab_close(session)

        return {"confirmed": False, "output": ""}

    async def _test_storage_exposure(self, url: str, config: dict) -> dict:
        """Scan localStorage, sessionStorage, cookies, and JS globals for exposed secrets.

        Uses agent-browser to load the page and extract all browser storage.
        Critical for DeFi/Web3 apps that may store private keys or JWT tokens
        client-side, and for detecting insecure cookie configurations.
        """
        from ...tools.web.agent_browser_tool import agent_browser_storage_scan
        scope_rules = config.get("scope_rules", {})

        result = await agent_browser_storage_scan(url, scope_rules)
        if result.get("error"):
            return {"confirmed": False, "output": result["error"]}

        secrets     = result.get("secrets_found", [])
        cookie_issues = result.get("cookie_issues", [])

        if secrets:
            secret_summary = "; ".join(f"{s['type']} in {s['source']}" for s in secrets[:3])
            return {
                "confirmed":   True,
                "output":      f"Secrets found in browser storage: {secret_summary}",
                "description": (
                    f"Sensitive data exposed in client-side storage at {url}. "
                    f"Found: {len(secrets)} secret(s), {len(cookie_issues)} cookie issue(s)."
                ),
                "request":     {"url": url, "technique": "storage_scan"},
                "response_diff": {
                    "secrets":       secrets,
                    "cookie_issues": cookie_issues,
                    "localStorage_keys":   list((result.get("localStorage") or {}).keys()),
                    "sessionStorage_keys": list((result.get("sessionStorage") or {}).keys()),
                },
                "payload": "",
                "reproduction_steps": [
                    f"1. Navigate to {url}",
                    "2. Open DevTools → Application → Local Storage / Session Storage / Cookies",
                    f"3. Observe exposed secret(s): {secret_summary}",
                ],
            }

        if cookie_issues:
            issues_summary = "; ".join(
                f"{ci['name']}: {', '.join(ci['issues'])}" for ci in cookie_issues[:2]
            )
            return {
                "confirmed":   True,
                "output":      f"Cookie security issues: {issues_summary}",
                "description": f"Insecure cookie configuration at {url}",
                "request":     {"url": url, "technique": "cookie_audit"},
                "response_diff": {"cookie_issues": cookie_issues},
                "payload":     "",
                "reproduction_steps": [
                    f"1. Navigate to {url}",
                    "2. Open DevTools → Application → Cookies",
                    f"3. Observe: {issues_summary}",
                ],
            }

        return {"confirmed": False, "output": "No secrets or cookie issues found in browser storage"}

    # ── Evidence capture ──────────────────────────────────────────────────────

    async def _attach_screenshot_evidence(self, result: dict, url: str) -> dict:
        """Take an annotated screenshot of the vulnerable page and attach the path.

        Uses --annotate flag: overlays numbered element labels on the screenshot,
        making it easier to identify which element triggered the vulnerability.
        """
        from ...tools.web.agent_browser_tool import (
            ab_open, ab_screenshot, ab_close, new_session_id, is_available,
        )
        if not await is_available():
            return result

        session = new_session_id("evidence")
        try:
            await ab_open(url, session, wait_networkidle=True)
            safe_ts = _utcnow().replace(":", "-").replace("+", "")
            path    = f"/tmp/bm_evidence_{self.agent_id}_{safe_ts}.png"
            # annotate=True overlays numbered element refs for clearer bug reports
            await ab_screenshot(path, session, full_page=True, annotate=True)
            result = dict(result)
            result["screenshot_path"] = path
        except Exception:
            pass
        finally:
            await ab_close(session)

        return result

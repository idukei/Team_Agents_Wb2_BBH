import asyncio
import shutil
import httpx
from urllib.parse import urlparse
from ...tools.scope_checker import validate_scope


async def subfinder_scan(target: str, scope_rules: dict) -> list[str]:
    validate_scope(target, scope_rules)

    parsed = urlparse(target)
    domain = parsed.hostname or target.replace("https://", "").replace("http://", "").split("/")[0]

    subdomains = []

    if shutil.which("subfinder"):
        subdomains += await _subfinder_subprocess(domain)

    if shutil.which("amass"):
        subdomains += await _amass_subprocess(domain)

    if not subdomains:
        subdomains += await _crtsh_fallback(domain)

    seen = set()
    unique = []
    for s in subdomains:
        if s not in seen:
            seen.add(s)
            unique.append(s)

    return unique


async def _subfinder_subprocess(domain: str) -> list[str]:
    try:
        proc = await asyncio.create_subprocess_exec(
            "subfinder", "-d", domain, "-silent",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=60)
        return [line.strip() for line in stdout.decode().splitlines() if line.strip()]
    except Exception:
        return []


async def _amass_subprocess(domain: str) -> list[str]:
    try:
        proc = await asyncio.create_subprocess_exec(
            "amass", "enum", "-passive", "-d", domain,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=90)
        return [line.strip() for line in stdout.decode().splitlines() if line.strip()]
    except Exception:
        return []


async def _crtsh_fallback(domain: str) -> list[str]:
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"https://crt.sh/?q=%.{domain}&output=json",
                headers={"User-Agent": "BountyMind-Recon/4.0"},
            )
            if resp.status_code == 200:
                data = resp.json()
                subs = set()
                for entry in data:
                    name = entry.get("name_value", "")
                    for sub in name.splitlines():
                        sub = sub.strip().lstrip("*.")
                        if sub.endswith(domain) and sub != domain:
                            subs.add(sub)
                return list(subs)
    except Exception:
        pass
    return []

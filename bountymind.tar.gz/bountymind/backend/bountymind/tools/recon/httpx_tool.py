import asyncio
import re
from urllib.parse import urlparse, urlencode, urljoin
import httpx
from ...tools.scope_checker import validate_scope


TECH_SIGNATURES = {
    "nginx":     [("server", r"nginx")],
    "apache":    [("server", r"apache")],
    "express":   [("x-powered-by", r"express")],
    "php":       [("x-powered-by", r"php"), ("set-cookie", r"phpsessid")],
    "django":    [("set-cookie", r"csrftoken"), ("x-frame-options", r"sameorigin")],
    "rails":     [("x-request-id", r".*"), ("set-cookie", r"_session_id")],
    "next.js":   [("x-powered-by", r"next\.js")],
    "cloudflare":[("cf-ray", r".*")],
    "wordpress": [("x-pingback", r".*"), ("link", r"wp-json")],
    "laravel":   [("set-cookie", r"laravel_session")],
    "asp.net":   [("x-aspnet-version", r".*"), ("x-powered-by", r"asp\.net")],
    "react":     [("content-type", r"text/html")],
}


async def httpx_probe(
    urls: list[str],
    scope_rules: dict,
    timeout: int = 10,
    follow_redirects: bool = True,
) -> list[dict]:
    results = []

    async with httpx.AsyncClient(
        timeout=timeout,
        follow_redirects=follow_redirects,
        verify=False,
        headers={"User-Agent": "Mozilla/5.0 BountyMind-Recon/4.0"},
    ) as client:
        tasks = [_probe_single(client, url, scope_rules) for url in urls]
        raw = await asyncio.gather(*tasks, return_exceptions=True)

    for r in raw:
        if isinstance(r, dict):
            results.append(r)

    return results


async def _probe_single(client: httpx.AsyncClient, url: str, scope_rules: dict) -> dict:
    try:
        validate_scope(url, scope_rules)
    except Exception as e:
        return {}

    try:
        resp = await client.get(url)
        headers = dict(resp.headers)
        tech_hints = _detect_tech(headers)

        auth_required = resp.status_code in (401, 403) or (
            resp.status_code in (301, 302)
            and "login" in resp.headers.get("location", "").lower()
        )

        params = _extract_params(str(resp.url))

        return {
            "url":             str(resp.url),
            "method":          "GET",
            "status":          resp.status_code,
            "auth_required":   auth_required,
            "params":          params,
            "response_time_ms": int(resp.elapsed.total_seconds() * 1000) if resp.elapsed else 0,
            "tech_hints":      tech_hints,
            "content_length":  int(headers.get("content-length", 0)),
            "headers":         headers,
        }
    except Exception:
        return {}


def _detect_tech(headers: dict) -> list[str]:
    found = []
    lower_headers = {k.lower(): v.lower() for k, v in headers.items()}
    for tech, patterns in TECH_SIGNATURES.items():
        for header_name, pattern in patterns:
            val = lower_headers.get(header_name, "")
            if val and re.search(pattern, val, re.IGNORECASE):
                found.append(tech)
                break
    return list(set(found))


def _extract_params(url: str) -> list[str]:
    parsed = urlparse(url)
    if not parsed.query:
        return []
    return [p.split("=")[0] for p in parsed.query.split("&") if p]


async def probe_common_endpoints(base_url: str, scope_rules: dict) -> list[dict]:
    parsed = urlparse(base_url)
    base = f"{parsed.scheme}://{parsed.netloc}"

    common_paths = [
        "/", "/login", "/signup", "/register", "/forgot-password",
        "/reset-password", "/logout", "/api", "/api/v1", "/api/v2",
        "/admin", "/dashboard", "/profile", "/settings", "/account",
        "/health", "/status", "/.well-known/security.txt",
        "/robots.txt", "/sitemap.xml", "/swagger.json", "/openapi.json",
        "/api-docs", "/graphql", "/api/graphql", "/wp-admin", "/wp-login.php",
        "/phpmyadmin", "/.env", "/config", "/static", "/assets",
        "/auth/login", "/auth/register", "/auth/forgot", "/oauth/authorize",
        "/api/auth/login", "/api/users", "/api/user/me",
    ]

    urls = [urljoin(base, path) for path in common_paths]
    return await httpx_probe(urls, scope_rules, timeout=8)

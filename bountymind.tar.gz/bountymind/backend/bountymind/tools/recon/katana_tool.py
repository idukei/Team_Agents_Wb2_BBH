import asyncio
import json
import re
import shutil
from urllib.parse import urlparse, urljoin
import httpx
from ...tools.scope_checker import validate_scope


async def katana_crawl(target: str, scope_rules: dict, depth: int = 2) -> dict:
    validate_scope(target, scope_rules)

    if shutil.which("katana"):
        return await _katana_subprocess(target, depth)
    else:
        return await _httpx_crawl_fallback(target, scope_rules, depth)


async def _katana_subprocess(target: str, depth: int) -> dict:
    try:
        proc = await asyncio.create_subprocess_exec(
            "katana",
            "-u", target,
            "-d", str(depth),
            "-jc",
            "-json",
            "-silent",
            "-timeout", "10",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=180)

        endpoints = []
        forms = []
        js_findings = []

        for line in stdout.decode().strip().splitlines():
            if not line.strip():
                continue
            try:
                item = json.loads(line)
                url = item.get("request", {}).get("endpoint", "")
                method = item.get("request", {}).get("method", "GET")

                if url:
                    endpoints.append({
                        "url":             url,
                        "method":          method,
                        "status":          item.get("response", {}).get("status_code", 0),
                        "auth_required":   False,
                        "params":          [],
                        "response_time_ms": 0,
                        "tech_hints":      [],
                    })

                if url.endswith(".js"):
                    js_findings.append({
                        "type":    "js_file",
                        "value":   url,
                        "url":     url,
                        "context": "katana_discovery",
                    })

            except json.JSONDecodeError:
                pass

        return {"endpoints": endpoints, "forms": forms, "js_findings": js_findings}
    except Exception:
        return await _httpx_crawl_fallback(target, {}, 1)


async def _httpx_crawl_fallback(target: str, scope_rules: dict, depth: int) -> dict:
    visited = set()
    to_visit = {target}
    endpoints = []
    forms = []
    js_findings = []

    parsed_base = urlparse(target)
    base_domain = parsed_base.netloc

    async with httpx.AsyncClient(
        timeout=10,
        follow_redirects=True,
        verify=False,
        headers={"User-Agent": "Mozilla/5.0 BountyMind-Crawl/4.0"},
    ) as client:
        for _ in range(depth):
            current_batch = to_visit - visited
            if not current_batch:
                break

            for url in list(current_batch)[:20]:
                if url in visited:
                    continue
                visited.add(url)

                try:
                    resp = await client.get(url)
                    html = resp.text

                    endpoints.append({
                        "url":             str(resp.url),
                        "method":          "GET",
                        "status":          resp.status_code,
                        "auth_required":   resp.status_code in (401, 403),
                        "params":          [],
                        "response_time_ms": int(resp.elapsed.total_seconds() * 1000) if resp.elapsed else 0,
                        "tech_hints":      [],
                    })

                    forms += _extract_forms(html, str(resp.url))
                    js_findings += _extract_js_urls(html, str(resp.url))

                    for href in re.findall(r'href=["\']([^"\']+)["\']', html):
                        abs_url = urljoin(str(resp.url), href)
                        if urlparse(abs_url).netloc == base_domain and abs_url not in visited:
                            to_visit.add(abs_url)
                except Exception:
                    pass

    return {"endpoints": endpoints, "forms": forms, "js_findings": js_findings}


def _extract_forms(html: str, page_url: str) -> list[dict]:
    forms = []
    form_pattern = re.compile(r'<form([^>]*)>(.*?)</form>', re.DOTALL | re.IGNORECASE)
    input_pattern = re.compile(r'<input([^>]*)>', re.IGNORECASE)
    textarea_pattern = re.compile(r'<textarea([^>]*)>', re.IGNORECASE)

    for form_match in form_pattern.finditer(html):
        attrs_str = form_match.group(1)
        form_body = form_match.group(2)

        action = re.search(r'action=["\']([^"\']*)["\']', attrs_str)
        method = re.search(r'method=["\']([^"\']*)["\']', attrs_str)

        fields = []
        for inp in input_pattern.finditer(form_body):
            inp_attrs = inp.group(1)
            name = re.search(r'name=["\']([^"\']*)["\']', inp_attrs)
            itype = re.search(r'type=["\']([^"\']*)["\']', inp_attrs)
            required = 'required' in inp_attrs.lower()
            if name:
                fields.append({
                    "name":       name.group(1),
                    "type":       itype.group(1) if itype else "text",
                    "required":   required,
                    "validation": "",
                })
        for ta in textarea_pattern.finditer(form_body):
            ta_attrs = ta.group(1)
            name = re.search(r'name=["\']([^"\']*)["\']', ta_attrs)
            if name:
                fields.append({
                    "name":       name.group(1),
                    "type":       "textarea",
                    "required":   'required' in ta_attrs.lower(),
                    "validation": "",
                })

        if fields:
            forms.append({
                "url":             page_url,
                "action":          action.group(1) if action else page_url,
                "method":          (method.group(1) if method else "GET").upper(),
                "fields":          fields,
                "submit_behavior": "unknown",
                "error_messages":  [],
            })

    return forms


def _extract_js_urls(html: str, page_url: str) -> list[dict]:
    js_files = []
    for src in re.findall(r'<script[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE):
        abs_url = urljoin(page_url, src)
        js_files.append({
            "type":    "js_file",
            "value":   abs_url,
            "url":     page_url,
            "context": "script_src",
        })
    return js_files

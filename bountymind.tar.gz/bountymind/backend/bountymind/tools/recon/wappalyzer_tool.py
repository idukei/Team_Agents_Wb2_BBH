import re
import httpx
from urllib.parse import urlparse
from ...tools.scope_checker import validate_scope


WAPPALYZER_SIGS = {
    "React":       {"headers": {}, "scripts": [r"react(?:\.min)?\.js"], "html": [r'data-reactroot', r'__NEXT_DATA__']},
    "Vue.js":      {"headers": {}, "scripts": [r"vue(?:\.min)?\.js"], "html": [r'__vue__', r'data-v-']},
    "Angular":     {"headers": {}, "scripts": [r"angular(?:\.min)?\.js"], "html": [r'ng-version=', r'\[ng-version\]']},
    "Next.js":     {"headers": {"x-powered-by": r"next\.js"}, "scripts": [r"/_next/"], "html": [r'__NEXT_DATA__']},
    "Nuxt.js":     {"headers": {}, "scripts": [r"/_nuxt/"], "html": [r'__nuxt']},
    "jQuery":      {"scripts": [r"jquery(?:\.min)?\.js"], "html": []},
    "Bootstrap":   {"scripts": [r"bootstrap(?:\.min)?\.js"], "html": [r'class=["\'][^"\']*btn-']},
    "WordPress":   {"html": [r'/wp-content/', r'/wp-includes/'], "headers": {}},
    "Drupal":      {"html": [r'Drupal\.settings', r'/sites/default/files/'], "headers": {}},
    "Joomla":      {"html": [r'/media/jui/', r'joomla'], "headers": {}},
    "Django":      {"headers": {"set-cookie": r"csrftoken"}, "html": []},
    "Rails":       {"headers": {"x-powered-by": r"phusion passenger"}, "html": []},
    "Laravel":     {"headers": {"set-cookie": r"laravel_session"}, "html": []},
    "Express":     {"headers": {"x-powered-by": r"express"}, "html": []},
    "Nginx":       {"headers": {"server": r"nginx"}, "html": []},
    "Apache":      {"headers": {"server": r"apache"}, "html": []},
    "Cloudflare":  {"headers": {"cf-ray": r".*"}, "html": []},
    "AWS CloudFront": {"headers": {"via": r"cloudfront"}, "html": []},
    "Vercel":      {"headers": {"x-vercel-id": r".*"}, "html": []},
    "Netlify":     {"headers": {"x-nf-request-id": r".*"}, "html": []},
    "Stripe":      {"scripts": [r"js\.stripe\.com"], "html": [r'stripe']},
    "Google Analytics": {"scripts": [r"google-analytics\.com", r"gtag"], "html": []},
    "Intercom":    {"scripts": [r"widget\.intercom\.io"], "html": []},
    "Sentry":      {"scripts": [r"sentry\.io", r"cdn\.ravenjs\.com"], "html": []},
    "GraphQL":     {"html": [r'__typename', r'graphql'], "headers": {}},
    "Webpack":     {"scripts": [r"webpack"], "html": [r'webpackJsonp', r'__webpack_require__']},
}


async def wappalyzer_fingerprint(target: str, scope_rules: dict) -> list[dict]:
    validate_scope(target, scope_rules)

    try:
        async with httpx.AsyncClient(
            timeout=15,
            follow_redirects=True,
            verify=False,
            headers={"User-Agent": "Mozilla/5.0 BountyMind-Tech/4.0"},
        ) as client:
            resp = await client.get(target)
            html = resp.text
            headers = {k.lower(): v.lower() for k, v in resp.headers.items()}
            scripts_content = " ".join(re.findall(r'src=["\']([^"\']+)["\']', html))

            detected = []
            for tech, sigs in WAPPALYZER_SIGS.items():
                confidence = 0.0
                detected_via = []

                for header_name, pattern in (sigs.get("headers") or {}).items():
                    if header_name in headers and re.search(pattern, headers[header_name], re.I):
                        confidence = max(confidence, 0.9)
                        detected_via.append(f"header:{header_name}")

                for pattern in sigs.get("scripts", []):
                    if re.search(pattern, scripts_content, re.I):
                        confidence = max(confidence, 0.85)
                        detected_via.append(f"script:{pattern[:20]}")

                for pattern in sigs.get("html", []):
                    if re.search(pattern, html, re.I):
                        confidence = max(confidence, 0.75)
                        detected_via.append(f"html:{pattern[:20]}")

                if confidence > 0:
                    version = _extract_version(tech, html, headers)
                    detected.append({
                        "name":         tech,
                        "version":      version,
                        "confidence":   round(confidence, 2),
                        "detected_via": ", ".join(detected_via[:2]),
                    })

            server_header = resp.headers.get("server", "")
            if server_header:
                server_version = _parse_server_version(server_header)
                already_found = [t["name"].lower() for t in detected]
                for tech_name in ["Nginx", "Apache", "IIS"]:
                    if tech_name.lower() in server_header.lower() and tech_name.lower() not in already_found:
                        detected.append({
                            "name":         tech_name,
                            "version":      server_version,
                            "confidence":   0.95,
                            "detected_via": "server-header",
                        })

            return detected
    except Exception:
        return []


def _extract_version(tech: str, html: str, headers: dict) -> str:
    version_patterns = {
        "React":    r'react@(\d+\.\d+\.\d+)',
        "Vue.js":   r'vue@(\d+\.\d+\.\d+)',
        "Angular":  r'ng-version="(\d+\.\d+\.\d+)"',
        "jQuery":   r'jquery[/-](\d+\.\d+\.\d+)',
        "Bootstrap":r'bootstrap[/-](\d+\.\d+\.\d+)',
        "WordPress":r'ver=(\d+\.\d+)',
        "Nginx":    r'nginx/(\d+\.\d+\.\d+)',
        "Apache":   r'apache/(\d+\.\d+\.\d+)',
    }
    pattern = version_patterns.get(tech)
    if pattern:
        m = re.search(pattern, html + " " + " ".join(headers.values()), re.I)
        if m:
            return m.group(1)
    return ""


def _parse_server_version(server: str) -> str:
    m = re.search(r'[\w-]+/(\d+[\d.]+)', server)
    return m.group(1) if m else ""

import asyncio
import shutil
import httpx
from urllib.parse import urlparse
from ...tools.scope_checker import validate_scope


async def gau_fetch(target: str, scope_rules: dict) -> list[dict]:
    validate_scope(target, scope_rules)

    parsed = urlparse(target)
    domain = parsed.hostname or target.replace("https://", "").replace("http://", "").split("/")[0]

    urls = []

    if shutil.which("gau"):
        urls += await _gau_subprocess(domain)

    if shutil.which("waybackurls"):
        urls += await _waybackurls_subprocess(domain)

    if not urls:
        urls += await _wayback_api_fallback(domain)

    seen = set()
    endpoints = []
    for url in urls:
        if url not in seen:
            seen.add(url)
            parsed_url = urlparse(url)
            params = [p.split("=")[0] for p in (parsed_url.query or "").split("&") if p]
            endpoints.append({
                "url":             url,
                "method":          "GET",
                "status":          0,
                "auth_required":   False,
                "params":          params,
                "response_time_ms": 0,
                "tech_hints":      ["historical"],
                "source":          "gau",
            })

    return endpoints


async def _gau_subprocess(domain: str) -> list[str]:
    try:
        proc = await asyncio.create_subprocess_exec(
            "gau", "--subs", domain,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=60)
        return [line.strip() for line in stdout.decode().splitlines() if line.strip().startswith("http")]
    except Exception:
        return []


async def _waybackurls_subprocess(domain: str) -> list[str]:
    try:
        proc = await asyncio.create_subprocess_exec(
            "waybackurls", domain,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=60)
        return [line.strip() for line in stdout.decode().splitlines() if line.strip().startswith("http")]
    except Exception:
        return []


async def _wayback_api_fallback(domain: str) -> list[str]:
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(
                f"http://web.archive.org/cdx/search/cdx",
                params={
                    "url":      f"*.{domain}/*",
                    "output":   "text",
                    "fl":       "original",
                    "collapse": "urlkey",
                    "limit":    "200",
                },
                headers={"User-Agent": "BountyMind-Recon/4.0"},
            )
            if resp.status_code == 200:
                return [line.strip() for line in resp.text.splitlines() if line.strip().startswith("http")]
    except Exception:
        pass
    return []

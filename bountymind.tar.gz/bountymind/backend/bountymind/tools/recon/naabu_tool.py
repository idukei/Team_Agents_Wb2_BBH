import asyncio
import shutil
from urllib.parse import urlparse


COMMON_PORTS = [
    21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 993, 995,
    1433, 1521, 2375, 2376, 3000, 3306, 3389, 4567, 5000,
    5432, 5601, 6379, 6443, 7000, 7001, 8000, 8080, 8081,
    8082, 8443, 8500, 8888, 9000, 9090, 9200, 9300, 27017,
]

SERVICE_MAP = {
    21:    "FTP",       22:    "SSH",       23:    "Telnet",
    25:    "SMTP",      53:    "DNS",       80:    "HTTP",
    443:   "HTTPS",     445:   "SMB",       1433:  "MSSQL",
    1521:  "Oracle",    2375:  "Docker",    3000:  "Node/Dev",
    3306:  "MySQL",     3389:  "RDP",       4567:  "Sinatra",
    5000:  "Flask/Dev", 5432:  "PostgreSQL",5601:  "Kibana",
    6379:  "Redis",     8000:  "HTTP-Alt",  8080:  "HTTP-Proxy",
    8443:  "HTTPS-Alt", 8500:  "Consul",    9200:  "Elasticsearch",
    9300:  "ES-Transport", 27017: "MongoDB",
}


async def naabu_scan(target: str, scope_rules: dict, top_ports: int = 50) -> list[dict]:
    host = _extract_host(target)
    if not host:
        return []

    if shutil.which("naabu"):
        return await _run_naabu(host, top_ports)

    return await _fallback_scan(host, top_ports)


def _extract_host(target: str) -> str:
    try:
        parsed = urlparse(target if "://" in target else "https://" + target)
        return parsed.hostname or ""
    except Exception:
        return ""


async def _run_naabu(host: str, top_ports: int) -> list[dict]:
    try:
        proc = await asyncio.create_subprocess_exec(
            "naabu", "-host", host, "-top-ports", str(top_ports),
            "-silent", "-json",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=60)

        import json
        results = []
        for line in stdout.decode().splitlines():
            try:
                data = json.loads(line)
                port = data.get("port", 0)
                results.append({
                    "host":    host,
                    "port":    port,
                    "service": SERVICE_MAP.get(port, "unknown"),
                })
            except Exception:
                pass
        return results
    except (asyncio.TimeoutError, FileNotFoundError, Exception):
        return await _fallback_scan(host, min(top_ports, 20))


async def _fallback_scan(host: str, top_ports: int) -> list[dict]:
    ports_to_scan = COMMON_PORTS[:top_ports]
    open_ports    = []

    async def _check(port: int) -> dict | None:
        try:
            _, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port), timeout=2
            )
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            return {"host": host, "port": port, "service": SERVICE_MAP.get(port, "unknown")}
        except Exception:
            return None

    tasks   = [_check(p) for p in ports_to_scan]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    for r in results:
        if isinstance(r, dict):
            open_ports.append(r)

    return open_ports

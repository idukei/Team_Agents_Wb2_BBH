from typing import Callable, Any

_REGISTRY: dict[str, Callable] = {}
_DESCRIPTIONS: dict[str, str] = {}


class ToolRegistry:
    @classmethod
    def register(cls, name: str, description: str = ""):
        def decorator(fn: Callable) -> Callable:
            _REGISTRY[name]      = fn
            _DESCRIPTIONS[name]  = description
            return fn
        return decorator

    @classmethod
    def get(cls, name: str) -> Callable:
        if name not in _REGISTRY:
            raise KeyError(f"Tool '{name}' not registered")
        return _REGISTRY[name]

    @classmethod
    def list_all(cls) -> dict[str, Callable]:
        return dict(_REGISTRY)

    @classmethod
    def list_all_with_descriptions(cls) -> str:
        if not _REGISTRY:
            return "No tools registered yet"
        lines = []
        for name, desc in _DESCRIPTIONS.items():
            lines.append(f"- {name}: {desc or 'no description'}")
        return "\n".join(lines)


# ── Built-in tool registrations ───────────────────────────────────────────────
import uuid as _uuid

from .web.js_bundle_tool   import analyze_js_bundle      as _js_bundle
from .recon.naabu_tool     import naabu_scan             as _naabu
from .osint.github_search  import github_advisory_search as _gh_advisory
from .web.agent_browser_tool import (
    agent_browser_navigate       as _ab_navigate,
    agent_browser_screenshot_url as _ab_screenshot,
    agent_browser_storage_scan   as _ab_storage,
    agent_browser_network_capture as _ab_netcap,
)


@ToolRegistry.register("js_bundle_analyzer",
    "Analyze JavaScript bundles for secrets, API keys, and hardcoded endpoints")
async def _tool_js_bundle(target: str, **kw):
    return await _js_bundle([target], kw.get("scope_rules", {}))


@ToolRegistry.register("port_scan",
    "Scan target host for open ports using naabu (top N ports)")
async def _tool_port_scan(target: str, **kw):
    return await _naabu(target, kw.get("scope_rules", {}), kw.get("top_ports", 50))


@ToolRegistry.register("github_advisory",
    "Search GitHub Advisory Database for CVEs affecting a package")
async def _tool_gh_advisory(target: str, **kw):
    return await _gh_advisory(target)


@ToolRegistry.register(
    "agent_browser_navigate",
    "Navigate to a URL and return a compact accessibility tree snapshot (~200-400 tokens). "
    "Renders JavaScript. Use for JS-heavy dApps, SPAs, or pages where HTTPX returns no useful content.",
)
async def _tool_ab_navigate(target: str, **kw):
    return await _ab_navigate(target, kw.get("scope_rules", {}))


@ToolRegistry.register(
    "agent_browser_screenshot",
    "Navigate to a URL and save an annotated screenshot to disk. Returns the file path. "
    "Use to capture evidence when a vulnerability is confirmed.",
)
async def _tool_ab_screenshot(target: str, **kw):
    path = kw.get("output_path", f"/tmp/bm_screenshot_{_uuid.uuid4().hex[:8]}.png")
    return await _ab_screenshot(target, path, kw.get("scope_rules", {}))


@ToolRegistry.register(
    "agent_browser_storage_scan",
    "Scan localStorage, sessionStorage, cookies, and JS globals for exposed secrets. "
    "Detects JWT tokens, API keys, private keys, and insecure cookie flags. "
    "Critical for DeFi/Web3 dApps that may store credentials client-side.",
)
async def _tool_ab_storage(target: str, **kw):
    return await _ab_storage(target, kw.get("scope_rules", {}))


@ToolRegistry.register(
    "agent_browser_network_capture",
    "Navigate to a URL and capture all XHR/fetch network traffic as a HAR file. "
    "Returns discovered API endpoints and any auth headers found in requests. "
    "Use for hidden endpoint discovery and token leakage detection.",
)
async def _tool_ab_netcap(target: str, **kw):
    har_path = kw.get("har_path", f"/tmp/bm_har_{_uuid.uuid4().hex[:8]}.har")
    return await _ab_netcap(target, kw.get("scope_rules", {}), har_path)

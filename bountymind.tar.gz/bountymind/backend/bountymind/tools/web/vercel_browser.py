import re
import asyncio
import httpx
from urllib.parse import urlparse, urljoin
from ...tools.scope_checker import validate_scope


async def browser_scrape(
    url: str,
    scope_rules: dict,
    extract_forms: bool = True,
    extract_links: bool = True,
) -> dict:
    validate_scope(url, scope_rules)

    # Tier 0: agent-browser — token-efficient accessibility tree, JS rendering, isolated sessions
    try:
        ab_result = await _try_agent_browser(url, extract_forms, extract_links)
        if ab_result:
            return ab_result
    except Exception:
        pass

    # Tier 1: Playwright — full JS rendering
    try:
        playwright_result = await _try_playwright(url, extract_forms, extract_links)
        if playwright_result:
            return playwright_result
    except ImportError:
        pass
    except Exception:
        pass

    # Tier 2: HTTPX — static HTML only
    return await _httpx_fallback(url, scope_rules, extract_forms, extract_links)


async def _try_agent_browser(url: str, extract_forms: bool, extract_links: bool) -> dict | None:
    """Tier 0 browser: agent-browser CLI (Rust, Chrome DevTools Protocol).

    Improvements over plain Playwright/HTTPX:
    - Blocks images/fonts/CSS to reduce load time
    - Waits for networkidle so JS-rendered content is present before snapshotting
    - Extracts real cookies with security attributes (httpOnly, secure, sameSite)
    - Returns compact accessibility tree (~200-400 tokens) instead of raw HTML
    """
    from .agent_browser_tool import (
        is_available, ab_open, ab_close, ab_cookies,
        ab_network_route_abort, new_session_id,
        _BLOCK_RESOURCES_PATTERN,
    )

    if not await is_available():
        return None

    session = new_session_id("recon")
    try:
        # Block heavy resources (images, fonts, CSS) for faster recon
        await ab_network_route_abort(_BLOCK_RESOURCES_PATTERN, session)

        # ab_open already waits for networkidle by default
        snapshot = await ab_open(url, session, wait_networkidle=True)
        if not snapshot or not snapshot.strip():
            return None

        forms: list[dict] = []
        links: list[dict] = []

        if extract_forms:
            forms = _parse_forms_from_snapshot(snapshot, url)
        if extract_links:
            links = _parse_links_from_snapshot(snapshot, url)

        auth_mechanisms = _detect_auth_from_snapshot(snapshot, forms, url)

        # Real cookie extraction with security attributes
        raw_cookies = await ab_cookies(session)
        cookies = [
            {
                "name":     c.get("name", ""),
                "domain":   c.get("domain", ""),
                "httpOnly": c.get("httpOnly", False),
                "secure":   c.get("secure", False),
                "sameSite": c.get("sameSite", ""),
            }
            for c in raw_cookies
        ]

        return {
            "html":            snapshot[:5000],
            "forms":           forms,
            "external_links":  [lnk for lnk in links if _is_external(lnk["url"], url)],
            "auth_mechanisms": auth_mechanisms,
            "cookies":         cookies,
            "_source":         "agent-browser",
        }
    except Exception:
        return None
    finally:
        await ab_close(session)


def _parse_forms_from_snapshot(snapshot: str, base_url: str) -> list[dict]:
    """Extract form-like structures from an accessibility tree snapshot."""
    forms = []
    # Look for button[type=submit] or input[type=submit] patterns in the snapshot
    has_submit = bool(re.search(r'(?:submit|button|login|sign in|register)', snapshot, re.I))
    if not has_submit:
        return forms

    # Identify input fields from refs
    fields = []
    for m in re.finditer(r'(@e\d+)\s+([^\n]+)', snapshot):
        text = m.group(2).strip().lower()
        if any(k in text for k in ("input", "text field", "email", "password", "search", "username")):
            field_type = "password" if "password" in text else "email" if "email" in text else "text"
            fields.append({"name": text.split()[0], "type": field_type, "required": False, "validation": ""})

    if fields:
        has_csrf = any("csrf" in f["name"].lower() for f in fields)
        obs = []
        if not has_csrf:
            obs.append("No CSRF token detected in accessibility tree")
        forms.append({
            "url":             base_url,
            "action":          base_url,
            "method":          "POST",
            "fields":          fields,
            "submit_behavior": "unknown",
            "error_messages":  obs,
        })
    return forms


def _parse_links_from_snapshot(snapshot: str, base_url: str) -> list[dict]:
    """Extract links from an accessibility tree snapshot."""
    links = []
    for m in re.finditer(r'link\s+["\']?([^\n"\']+)["\']?\s+(?:href=|url=)?([^\s]+)', snapshot, re.I):
        href = m.group(2).strip()
        if href.startswith("http"):
            accepts_input = any(p in href.lower() for p in ["?", "url=", "redirect=", "return=", "next="])
            links.append({"url": href, "context": m.group(1).strip(), "accepts_user_input": accepts_input})
    return links


def _detect_auth_from_snapshot(snapshot: str, forms: list, base_url: str) -> list[dict]:
    """Detect auth mechanisms from an accessibility tree snapshot."""
    mechanisms = []
    lower = snapshot.lower()

    if any(f for f in forms if any(field["type"] == "password" for field in f.get("fields", []))):
        login_form = next((f for f in forms if any(fld["type"] == "password" for fld in f.get("fields", []))), None)
        obs = ["No CSRF token detected in login form"] if login_form and login_form.get("error_messages") else []
        mechanisms.append({
            "type":                "form_login",
            "implementation":      login_form["action"] if login_form else base_url,
            "endpoints_protected": [],
            "observations":        obs,
        })

    if "google" in lower and ("sign in with google" in lower or "oauth" in lower):
        mechanisms.append({"type": "oauth_google", "implementation": "Google OAuth",
                           "endpoints_protected": [], "observations": ["Google OAuth detected in snapshot"]})

    if "github" in lower and ("sign in with github" in lower or "oauth" in lower):
        mechanisms.append({"type": "oauth_github", "implementation": "GitHub OAuth",
                           "endpoints_protected": [], "observations": ["GitHub OAuth detected in snapshot"]})

    if "jwt" in lower or "bearer" in lower:
        mechanisms.append({"type": "jwt", "implementation": "JWT/Bearer token",
                           "endpoints_protected": [], "observations": ["JWT/Bearer pattern in snapshot"]})

    return mechanisms


async def _try_playwright(url: str, extract_forms: bool, extract_links: bool) -> dict | None:
    try:
        from playwright.async_api import async_playwright
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(
                user_agent="Mozilla/5.0 BountyMind-Browser/4.0",
                ignore_https_errors=True,
            )
            page = await context.new_page()
            await page.goto(url, wait_until="networkidle", timeout=15000)
            html = await page.content()
            cookies = await context.cookies()
            await browser.close()

            forms = _parse_forms(html, url) if extract_forms else []
            links = _parse_links(html, url) if extract_links else []
            auth_mechanisms = _detect_auth_mechanisms(html, forms, url)

            return {
                "html":            html[:5000],
                "forms":           forms,
                "external_links":  [l for l in links if _is_external(l["url"], url)],
                "auth_mechanisms": auth_mechanisms,
                "cookies":         [{"name": c["name"], "domain": c["domain"],
                                     "httpOnly": c["httpOnly"], "secure": c["secure"],
                                     "sameSite": c.get("sameSite", "")} for c in cookies],
            }
    except ImportError:
        return None


async def _httpx_fallback(url: str, scope_rules: dict, extract_forms: bool, extract_links: bool) -> dict:
    try:
        async with httpx.AsyncClient(
            timeout=15,
            follow_redirects=True,
            verify=False,
            headers={"User-Agent": "Mozilla/5.0 BountyMind-Browser/4.0"},
        ) as client:
            resp = await client.get(url)
            html = resp.text
            cookies_raw = resp.cookies

            forms = _parse_forms(html, str(resp.url)) if extract_forms else []
            links = _parse_links(html, str(resp.url)) if extract_links else []
            auth_mechanisms = _detect_auth_mechanisms(html, forms, str(resp.url))

            cookies = []
            for name, value in cookies_raw.items():
                cookies.append({"name": name, "httpOnly": False, "secure": False, "sameSite": ""})

            return {
                "html":            html[:5000],
                "forms":           forms,
                "external_links":  [l for l in links if _is_external(l["url"], str(resp.url))],
                "auth_mechanisms": auth_mechanisms,
                "cookies":         cookies,
            }
    except Exception:
        return {"html": "", "forms": [], "external_links": [], "auth_mechanisms": [], "cookies": []}


def _parse_forms(html: str, base_url: str) -> list[dict]:
    forms = []
    for m in re.finditer(r'<form([^>]*)>(.*?)</form>', html, re.DOTALL | re.IGNORECASE):
        attrs = m.group(1)
        body  = m.group(2)

        action_m = re.search(r'action=["\']([^"\']*)["\']', attrs, re.I)
        method_m = re.search(r'method=["\']([^"\']*)["\']', attrs, re.I)
        action = urljoin(base_url, action_m.group(1)) if action_m else base_url
        method = (method_m.group(1) if method_m else "GET").upper()

        fields = []
        for inp in re.finditer(r'<input([^>]*)>', body, re.I):
            ia = inp.group(1)
            n = re.search(r'name=["\']([^"\']*)["\']', ia, re.I)
            t = re.search(r'type=["\']([^"\']*)["\']', ia, re.I)
            if n:
                fields.append({
                    "name":       n.group(1),
                    "type":       t.group(1) if t else "text",
                    "required":   "required" in ia.lower(),
                    "validation": "",
                })
        for ta in re.finditer(r'<textarea([^>]*)>', body, re.I):
            ta_a = ta.group(1)
            n = re.search(r'name=["\']([^"\']*)["\']', ta_a, re.I)
            if n:
                fields.append({"name": n.group(1), "type": "textarea", "required": "required" in ta_a.lower(), "validation": ""})

        if fields:
            forms.append({
                "url":             base_url,
                "action":          action,
                "method":          method,
                "fields":          fields,
                "submit_behavior": "unknown",
                "error_messages":  [],
            })
    return forms


def _parse_links(html: str, base_url: str) -> list[dict]:
    links = []
    for m in re.finditer(r'href=["\']([^"\'#\s]+)["\']', html, re.I):
        href = m.group(1)
        abs_url = urljoin(base_url, href)
        if abs_url.startswith("http"):
            context = _get_link_context(html, m.start())
            accepts_input = any(p in abs_url.lower() for p in ["?", "url=", "redirect=", "return=", "next="])
            links.append({
                "url":               abs_url,
                "context":           context,
                "accepts_user_input": accepts_input,
            })
    return links


def _detect_auth_mechanisms(html: str, forms: list, base_url: str) -> list[dict]:
    mechanisms = []
    lower_html = html.lower()

    if any(f for f in forms if any(field["type"] == "password" for field in f.get("fields", []))):
        login_form = next((f for f in forms if any(field["type"] == "password" for field in f.get("fields", []))), None)
        obs = []
        if login_form:
            has_csrf = any(f["name"].lower() in ("csrf", "csrftoken", "_token", "authenticity_token")
                          for f in login_form.get("fields", []))
            if not has_csrf:
                obs.append("No CSRF token detected in login form")
            if login_form.get("method", "GET") == "GET":
                obs.append("Login form uses GET method — credentials in URL")

        mechanisms.append({
            "type":                 "form_login",
            "implementation":       login_form["action"] if login_form else base_url,
            "endpoints_protected":  [],
            "observations":         obs,
        })

    if "google" in lower_html and ("oauth" in lower_html or "accounts.google.com" in lower_html):
        mechanisms.append({
            "type":                "oauth_google",
            "implementation":      "Google OAuth",
            "endpoints_protected": [],
            "observations":        ["Google OAuth detected"],
        })

    if "github" in lower_html and "oauth" in lower_html:
        mechanisms.append({
            "type":                "oauth_github",
            "implementation":      "GitHub OAuth",
            "endpoints_protected": [],
            "observations":        ["GitHub OAuth detected"],
        })

    if "jwt" in lower_html or "bearer" in lower_html:
        mechanisms.append({
            "type":                "jwt",
            "implementation":      "JWT/Bearer token",
            "endpoints_protected": [],
            "observations":        ["JWT/Bearer token pattern detected in HTML"],
        })

    return mechanisms


def _is_external(url: str, base_url: str) -> bool:
    try:
        return urlparse(url).netloc != urlparse(base_url).netloc
    except Exception:
        return False


def _get_link_context(html: str, pos: int, window: int = 80) -> str:
    start = max(0, pos - window)
    end = min(len(html), pos + window)
    return re.sub(r'\s+', ' ', html[start:end]).strip()

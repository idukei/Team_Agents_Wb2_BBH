import re
import httpx

SECRET_PATTERNS: list[tuple[str, str]] = [
    ("api_key",      r'(?:api[_-]?key|apikey)\s*[:=]\s*["\']?([A-Za-z0-9_\-]{20,})["\']?'),
    ("aws_key",      r'AKIA[0-9A-Z]{16}'),
    ("stripe_key",   r'(?:sk|pk)_(?:live|test)_[A-Za-z0-9]{24,}'),
    ("sendgrid",     r'SG\.[A-Za-z0-9_\-]{22,}\.[A-Za-z0-9_\-]{43,}'),
    ("jwt_secret",   r'(?:jwt[_-]?secret|JWT_SECRET)\s*[:=]\s*["\']?([A-Za-z0-9+/=_\-]{16,})["\']?'),
    ("private_key",  r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----'),
    ("google_oauth", r'[0-9]+-[A-Za-z0-9_]{32}\.apps\.googleusercontent\.com'),
    ("password",     r'(?:password|passwd|pwd)\s*[:=]\s*["\']([^"\']{6,})["\']'),
    ("token",        r'(?:token|auth_token|access_token)\s*[:=]\s*["\']([A-Za-z0-9_\-\.]{20,})["\']'),
    ("secret",       r'(?:secret|client_secret)\s*[:=]\s*["\']([A-Za-z0-9_\-\.+/=]{16,})["\']'),
]

ENDPOINT_PATTERN = re.compile(
    r'["\`](/(?:api|v\d|graphql|rest|internal)[^\s"\'`]{1,200})["\`]',
    re.IGNORECASE,
)


async def analyze_js_bundle(js_urls: list[str], scope_rules: dict) -> list[dict]:
    findings = []

    async with httpx.AsyncClient(timeout=15, verify=False) as client:
        for url in js_urls:
            try:
                resp = await client.get(url, headers={"User-Agent": "Mozilla/5.0 BountyMind/4.0"})
                if resp.status_code != 200:
                    continue
                content = resp.text

                for secret_type, pattern in SECRET_PATTERNS:
                    for m in re.finditer(pattern, content, re.IGNORECASE):
                        val = m.group(1) if m.lastindex else m.group(0)
                        if len(val) > 8:
                            findings.append({
                                "type":    secret_type,
                                "value":   val[:80],
                                "url":     url,
                                "context": content[max(0, m.start()-30):m.end()+30].strip(),
                            })

                for ep in ENDPOINT_PATTERN.findall(content):
                    findings.append({
                        "type":  "endpoint",
                        "value": ep,
                        "url":   url,
                    })

            except Exception:
                pass

    seen  = set()
    dedup = []
    for f in findings:
        key = f"{f['type']}:{f['value'][:40]}"
        if key not in seen:
            seen.add(key)
            dedup.append(f)

    return dedup

"""agent_browser_tool.py — BountyMind wrapper for the agent-browser CLI.

agent-browser is a headless browser automation CLI built for AI agents:
  - Compact accessibility tree output (~200-400 tokens vs 3000-5000 for raw HTML)
  - Chrome DevTools Protocol via a persistent Rust daemon
  - Isolated sessions per agent invocation
  - 50+ commands: navigation, forms, network, storage, dialogs, JS eval

Install:
    npm install -g agent-browser
    agent-browser install        # downloads Chrome

Env:
    AGENT_BROWSER_BIN   path to binary (default: "agent-browser")
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import uuid

from ..scope_checker import validate_scope, ScopeViolationError

AGENT_BROWSER_BIN = os.getenv("AGENT_BROWSER_BIN", "agent-browser")

# Patterns that indicate secrets in storage/eval output
_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("jwt",        re.compile(r'eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}')),
    ("api_key",    re.compile(r'(?:api[_\-]?key|apikey)\s*[:=]\s*["\']?([A-Za-z0-9_\-]{20,})["\']?', re.I)),
    ("aws_key",    re.compile(r'AKIA[0-9A-Z]{16}')),
    ("stripe",     re.compile(r'(?:sk|pk)_(?:live|test)_[A-Za-z0-9]{24,}')),
    ("private_key",re.compile(r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----')),
    ("token",      re.compile(r'(?:token|auth_token|access_token)\s*[:=]\s*["\']([A-Za-z0-9_\-\.]{20,})["\']', re.I)),
    ("secret",     re.compile(r'(?:secret|client_secret)\s*[:=]\s*["\']([A-Za-z0-9_\-\.+/=]{16,})["\']', re.I)),
    ("password",   re.compile(r'(?:password|passwd)\s*[:=]\s*["\']([^"\']{6,})["\']', re.I)),
]

# Resource types to block during recon for speed
_BLOCK_RESOURCES_PATTERN = "*.{png,jpg,jpeg,gif,svg,ico,woff,woff2,ttf,eot,mp4,webm}"


# ── Low-level CLI wrapper ────────────────────────────────────────────────────

async def _run_cmd(*args: str, timeout: int = 30) -> str:
    """Execute agent-browser CLI and return stdout."""
    try:
        proc = await asyncio.create_subprocess_exec(
            AGENT_BROWSER_BIN, *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return stdout.decode()
    except FileNotFoundError:
        raise RuntimeError(
            f"agent-browser not found at '{AGENT_BROWSER_BIN}'. "
            "Install: npm install -g agent-browser && agent-browser install"
        )
    except asyncio.TimeoutError:
        raise RuntimeError(f"agent-browser command timed out after {timeout}s")


# ── Session helpers ───────────────────────────────────────────────────────────

def new_session_id(prefix: str = "bm") -> str:
    """Generate a unique session ID for an isolated browser session."""
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


# ── Navigation ────────────────────────────────────────────────────────────────

async def ab_open(url: str, session: str, wait_networkidle: bool = True) -> str:
    """Open URL in session, optionally wait for JS to finish loading.

    Returns the accessibility tree snapshot after load.
    Using wait_networkidle=True (default) ensures JS-rendered content is present
    before snapshotting — critical for SPAs and DeFi dApps.
    """
    await _run_cmd("open", url, "--session", session)
    if wait_networkidle:
        try:
            await _run_cmd("wait", "--load", "networkidle", "--session", session, timeout=20)
        except Exception:
            pass  # best-effort — proceed even if wait times out
    return await _run_cmd("snapshot", "--session", session)


async def ab_back(session: str) -> None:
    await _run_cmd("back", "--session", session)


async def ab_forward(session: str) -> None:
    await _run_cmd("forward", "--session", session)


async def ab_reload(session: str) -> str:
    await _run_cmd("reload", "--session", session)
    try:
        await _run_cmd("wait", "--load", "networkidle", "--session", session, timeout=20)
    except Exception:
        pass
    return await _run_cmd("snapshot", "--session", session)


# ── Snapshot & element reading ────────────────────────────────────────────────

async def ab_snapshot(session: str) -> str:
    """Return the current accessibility tree of the active session."""
    return await _run_cmd("snapshot", "--session", session)


async def ab_get_url(session: str) -> str:
    """Return the current URL (after any JS-based redirects)."""
    return (await _run_cmd("get", "url", "--session", session)).strip()


async def ab_get_text(ref: str, session: str) -> str:
    """Return the text content of an element by ref."""
    return (await _run_cmd("get", "text", ref, "--session", session)).strip()


async def ab_get_attr(ref: str, attr: str, session: str) -> str:
    """Return an attribute value of an element by ref."""
    return (await _run_cmd("get", "attr", ref, attr, "--session", session)).strip()


async def ab_get_title(session: str) -> str:
    return (await _run_cmd("get", "title", "--session", session)).strip()


async def ab_is_visible(ref: str, session: str) -> bool:
    result = (await _run_cmd("is", "visible", ref, "--session", session)).strip().lower()
    return result == "true"


# ── Interaction ───────────────────────────────────────────────────────────────

async def ab_click(ref: str, session: str) -> str:
    return await _run_cmd("click", ref, "--session", session)


async def ab_fill(ref: str, value: str, session: str) -> str:
    """Clear and fill a form field (use for replacing content)."""
    return await _run_cmd("fill", ref, value, "--session", session)


async def ab_type(ref: str, value: str, session: str) -> str:
    """Type into a field without clearing first."""
    return await _run_cmd("type", ref, value, "--session", session)


async def ab_press(key: str, session: str) -> str:
    """Press a key (e.g. 'Enter', 'Tab', 'Control+a')."""
    return await _run_cmd("press", key, "--session", session)


async def ab_hover(ref: str, session: str) -> str:
    return await _run_cmd("hover", ref, "--session", session)


async def ab_select(ref: str, value: str, session: str) -> str:
    """Select a dropdown option by value."""
    return await _run_cmd("select", ref, value, "--session", session)


# ── Semantic locators ─────────────────────────────────────────────────────────

async def ab_find_label(label: str, action: str, session: str, value: str = "") -> str:
    """Interact with an element by its visible label text.

    More reliable than ref-based interaction for form fields.
    action: fill | click | type | hover | focus | check | uncheck
    """
    args = ["find", "label", label, action]
    if value:
        args.append(value)
    args += ["--session", session]
    return await _run_cmd(*args)


async def ab_find_placeholder(placeholder: str, action: str, session: str, value: str = "") -> str:
    """Interact with an element by its placeholder text."""
    args = ["find", "placeholder", placeholder, action]
    if value:
        args.append(value)
    args += ["--session", session]
    return await _run_cmd(*args)


async def ab_find_role(role: str, action: str, session: str, name: str = "", value: str = "") -> str:
    """Interact with an element by ARIA role (e.g. 'button', 'textbox')."""
    args = ["find", "role", role, action]
    if value:
        args.append(value)
    if name:
        args += ["--name", name]
    args += ["--session", session]
    return await _run_cmd(*args)


async def ab_find_text(text: str, action: str, session: str) -> str:
    """Interact with an element by its visible text content."""
    return await _run_cmd("find", "text", text, action, "--session", session)


# ── Wait ──────────────────────────────────────────────────────────────────────

async def ab_wait_text(text: str, session: str, timeout: int = 15) -> bool:
    """Wait until the given text appears on the page. Returns True if found."""
    try:
        await _run_cmd("wait", "--text", text, "--session", session, timeout=timeout)
        return True
    except Exception:
        return False


async def ab_wait_url(pattern: str, session: str, timeout: int = 15) -> bool:
    """Wait until the URL matches a glob pattern (e.g. '**/dashboard')."""
    try:
        await _run_cmd("wait", "--url", pattern, "--session", session, timeout=timeout)
        return True
    except Exception:
        return False


async def ab_wait_selector(selector: str, session: str, timeout: int = 15) -> bool:
    """Wait for an element to appear."""
    try:
        await _run_cmd("wait", selector, "--session", session, timeout=timeout)
        return True
    except Exception:
        return False


# ── Dialogs (critical for XSS confirmation) ──────────────────────────────────

async def ab_dialog_status(session: str) -> str:
    """Return dialog status string, e.g. 'open: alert(1)' or 'none'.

    Use this after injecting XSS payloads to confirm execution:
    if 'open' in await ab_dialog_status(session): # XSS confirmed
    """
    return (await _run_cmd("dialog", "status", "--session", session)).strip()


async def ab_dialog_accept(session: str, text: str = "") -> str:
    """Accept the open dialog (alert/confirm/prompt). Optionally pass text for prompts."""
    args = ["dialog", "accept"]
    if text:
        args.append(text)
    args += ["--session", session]
    return await _run_cmd(*args)


async def ab_dialog_dismiss(session: str) -> str:
    """Dismiss the open dialog (confirm/prompt)."""
    return await _run_cmd("dialog", "dismiss", "--session", session)


# ── JavaScript evaluation ─────────────────────────────────────────────────────

async def ab_eval(js: str, session: str) -> str:
    """Execute JavaScript in the page context and return the result.

    Examples:
        await ab_eval("document.cookie", session)
        await ab_eval("localStorage.getItem('token')", session)
        await ab_eval("Object.keys(localStorage)", session)
    """
    return (await _run_cmd("eval", js, "--session", session)).strip()


# ── Cookies & Storage ─────────────────────────────────────────────────────────

async def ab_cookies(session: str) -> list[dict]:
    """Return all cookies for the current session as a list of dicts.

    Each dict: {name, value, domain, path, httpOnly, secure, sameSite, expires}
    """
    raw = await _run_cmd("cookies", "--session", session)
    try:
        return json.loads(raw)
    except Exception:
        # Parse plain-text fallback
        cookies = []
        for line in raw.splitlines():
            if "=" in line:
                parts = line.split(";")
                name_val = parts[0].strip().split("=", 1)
                if len(name_val) == 2:
                    cookies.append({
                        "name":     name_val[0].strip(),
                        "value":    name_val[1].strip(),
                        "httpOnly": "httponly" in line.lower(),
                        "secure":   "secure"   in line.lower(),
                        "sameSite": "",
                    })
        return cookies


async def ab_storage_local(session: str) -> dict:
    """Return all localStorage key-value pairs as a dict."""
    raw = await _run_cmd("storage", "local", "--session", session)
    try:
        return json.loads(raw)
    except Exception:
        result = {}
        for line in raw.splitlines():
            if ":" in line:
                k, _, v = line.partition(":")
                result[k.strip()] = v.strip()
        return result


async def ab_storage_session(session: str) -> dict:
    """Return all sessionStorage key-value pairs as a dict."""
    raw = await _run_cmd("storage", "session", "--session", session)
    try:
        return json.loads(raw)
    except Exception:
        result = {}
        for line in raw.splitlines():
            if ":" in line:
                k, _, v = line.partition(":")
                result[k.strip()] = v.strip()
        return result


# ── Network ───────────────────────────────────────────────────────────────────

async def ab_network_route_abort(pattern: str, session: str) -> None:
    """Block all requests matching pattern (glob). Useful to skip images/fonts.

    Example: ab_network_route_abort("*.{png,jpg,gif,css,woff}", session)
    """
    await _run_cmd("network", "route", pattern, "--abort", "--session", session)


async def ab_network_unroute(session: str, pattern: str = "") -> None:
    """Remove network interception routes."""
    args = ["network", "unroute"]
    if pattern:
        args.append(pattern)
    args += ["--session", session]
    await _run_cmd(*args)


async def ab_network_har_start(session: str) -> None:
    """Start recording all HTTP requests/responses as HAR."""
    await _run_cmd("network", "har", "start", "--session", session)


async def ab_network_har_stop(output_path: str, session: str) -> str:
    """Stop HAR recording and save to output_path. Returns the path."""
    await _run_cmd("network", "har", "stop", output_path, "--session", session)
    return output_path


async def ab_network_requests(session: str, req_type: str = "", method: str = "",
                               status: str = "", filter_pattern: str = "") -> list[dict]:
    """Return captured network requests with optional filtering.

    Args:
        req_type:       "xhr,fetch" | "document" | etc.
        method:         "POST" | "GET" | etc.
        status:         "2xx" | "4xx" | "5xx" etc.
        filter_pattern: glob pattern to filter URLs
    """
    args = ["network", "requests"]
    if req_type:
        args += ["--type", req_type]
    if method:
        args += ["--method", method]
    if status:
        args += ["--status", status]
    if filter_pattern:
        args += ["--filter", filter_pattern]
    args += ["--session", session]

    raw = await _run_cmd(*args)
    try:
        return json.loads(raw)
    except Exception:
        # Return raw as single entry if not JSON
        return [{"raw": raw}] if raw.strip() else []


# ── Screenshot & recording ────────────────────────────────────────────────────

async def ab_screenshot(path: str, session: str, full_page: bool = False,
                         annotate: bool = False) -> str:
    """Save a screenshot. Returns the path.

    Args:
        full_page: capture entire scrollable page
        annotate:  overlay numbered element labels (better for bug reports)
    """
    args = ["screenshot", path]
    if full_page:
        args.append("--full")
    if annotate:
        args.append("--annotate")
    args += ["--session", session]
    await _run_cmd(*args)
    return path


async def ab_record_start(path: str, session: str) -> None:
    """Start recording a WebM video of the session (for video evidence)."""
    await _run_cmd("record", "start", path, "--session", session)


async def ab_record_stop(session: str) -> None:
    """Stop video recording."""
    await _run_cmd("record", "stop", "--session", session)


# ── Console & errors ──────────────────────────────────────────────────────────

async def ab_console(session: str) -> str:
    """Return JS console messages (info leaks, error details)."""
    return await _run_cmd("console", "--session", session)


async def ab_errors(session: str) -> str:
    """Return page-level JS errors."""
    return await _run_cmd("errors", "--session", session)


# ── Session lifecycle ─────────────────────────────────────────────────────────

async def ab_close(session: str) -> None:
    """Close and release the browser session."""
    try:
        await _run_cmd("close", "--session", session, timeout=10)
    except Exception:
        pass


# ── Availability check ────────────────────────────────────────────────────────

_available_cache: bool | None = None


async def is_available() -> bool:
    """Return True if agent-browser CLI is installed and reachable."""
    global _available_cache
    if _available_cache is not None:
        return _available_cache
    try:
        result = await _run_cmd("--version", timeout=5)
        _available_cache = bool(result.strip())
    except Exception:
        _available_cache = False
    return _available_cache


# ── Snapshot parsing ──────────────────────────────────────────────────────────

def parse_refs(snapshot: str) -> list[dict]:
    """Extract refs and their text labels from an accessibility tree snapshot."""
    refs = []
    for m in re.finditer(r'(@e\d+)\s+([^\n]+)', snapshot):
        refs.append({"ref": m.group(1), "text": m.group(2).strip()})
    return refs


def find_input_refs(snapshot: str) -> list[dict]:
    """Return refs that look like text input fields."""
    keywords = ("input", "search", "query", "text", "field", "username",
                 "email", "password", "message", "textbox")
    return [r for r in parse_refs(snapshot)
            if any(k in r["text"].lower() for k in keywords)]


def find_link_refs(snapshot: str) -> list[dict]:
    """Return refs that look like links."""
    return [r for r in parse_refs(snapshot) if "link" in r["text"].lower()]


# ── Secret scanning helpers ───────────────────────────────────────────────────

def scan_for_secrets(data: str | dict) -> list[dict]:
    """Scan a string or dict for known secret patterns.

    Returns list of findings: [{type, match, context}]
    """
    text = json.dumps(data) if isinstance(data, dict) else str(data)
    findings = []
    for secret_type, pattern in _SECRET_PATTERNS:
        for m in pattern.finditer(text):
            findings.append({
                "type":    secret_type,
                "match":   m.group(0)[:80],
                "context": text[max(0, m.start() - 30): m.end() + 30],
            })
    return findings


# ── High-level tool functions (used by ToolRegistry) ─────────────────────────

async def agent_browser_navigate(url: str, scope_rules: dict) -> dict:
    """Navigate to a URL and return a compact accessibility tree snapshot.

    Waits for networkidle (JS fully loaded), blocks images/fonts for speed.
    Returns: {snapshot, refs, url, title, cookies_count}
    Token usage: ~200-400 tokens vs 3000-5000 for raw HTML.
    """
    try:
        validate_scope(url, scope_rules)
    except ScopeViolationError as e:
        return {"error": str(e), "snapshot": "", "refs": [], "url": url}

    if not await is_available():
        return {"error": "agent-browser not installed", "snapshot": "", "refs": [], "url": url}

    session = new_session_id("nav")
    try:
        # Block heavy resources for faster recon
        await ab_network_route_abort(_BLOCK_RESOURCES_PATTERN, session)
        snapshot = await ab_open(url, session, wait_networkidle=True)
        refs     = parse_refs(snapshot)
        title    = await ab_get_title(session)
        final_url = await ab_get_url(session)
        cookies  = await ab_cookies(session)
        return {
            "snapshot":      snapshot,
            "refs":          refs,
            "url":           final_url,
            "title":         title,
            "cookies_count": len(cookies),
        }
    except Exception as e:
        return {"error": str(e), "snapshot": "", "refs": [], "url": url}
    finally:
        await ab_close(session)


async def agent_browser_screenshot_url(url: str, output_path: str, scope_rules: dict,
                                        annotate: bool = True) -> dict:
    """Navigate to URL and save an annotated screenshot. Returns path for evidence."""
    try:
        validate_scope(url, scope_rules)
    except ScopeViolationError as e:
        return {"error": str(e), "path": None, "url": url}

    if not await is_available():
        return {"error": "agent-browser not installed", "path": None, "url": url}

    session = new_session_id("ss")
    try:
        await ab_open(url, session, wait_networkidle=True)
        path = await ab_screenshot(output_path, session, annotate=annotate)
        return {"path": path, "url": url}
    except Exception as e:
        return {"error": str(e), "path": None, "url": url}
    finally:
        await ab_close(session)


async def agent_browser_storage_scan(url: str, scope_rules: dict) -> dict:
    """Scan localStorage, sessionStorage, cookies, and JS globals for exposed secrets.

    This is particularly valuable for DeFi/Web3 dApps that may store private keys,
    JWT tokens, or API credentials in browser storage.

    Returns: {localStorage, sessionStorage, cookies, secrets_found, cookie_issues}
    """
    try:
        validate_scope(url, scope_rules)
    except ScopeViolationError as e:
        return {"error": str(e)}

    if not await is_available():
        return {"error": "agent-browser not installed"}

    session = new_session_id("storage")
    try:
        await ab_open(url, session, wait_networkidle=True)

        local_storage   = await ab_storage_local(session)
        session_storage = await ab_storage_session(session)
        cookies         = await ab_cookies(session)

        # Also check JS globals for exposed credentials
        js_globals_raw = await ab_eval(
            "JSON.stringify(Object.entries(window).filter(([k]) => "
            "/(key|token|secret|password|auth|credential)/i.test(k))"
            ".reduce((a,[k,v])=>(a[k]=String(v).slice(0,200),a), {}))",
            session,
        )
        try:
            js_globals = json.loads(js_globals_raw)
        except Exception:
            js_globals = {}

        # Scan all collected data for secrets
        secrets_found: list[dict] = []
        for source, data in [
            ("localStorage",   local_storage),
            ("sessionStorage", session_storage),
            ("js_globals",     js_globals),
        ]:
            hits = scan_for_secrets(data)
            for h in hits:
                h["source"] = source
                secrets_found.append(h)

        # Cookie security issues
        cookie_issues: list[dict] = []
        for c in cookies:
            issues = []
            if not c.get("httpOnly"):
                issues.append("Missing HttpOnly — accessible via document.cookie (XSS risk)")
            if not c.get("secure"):
                issues.append("Missing Secure flag — transmitted over HTTP")
            samesite = (c.get("sameSite") or "").lower()
            if samesite not in ("strict", "lax"):
                issues.append(f"SameSite={samesite or 'none'} — CSRF risk")
            if issues:
                cookie_issues.append({"name": c.get("name"), "issues": issues})

        return {
            "localStorage":   local_storage,
            "sessionStorage": session_storage,
            "cookies":        cookies,
            "js_globals":     js_globals,
            "secrets_found":  secrets_found,
            "cookie_issues":  cookie_issues,
        }
    except Exception as e:
        return {"error": str(e)}
    finally:
        await ab_close(session)


async def agent_browser_network_capture(url: str, scope_rules: dict,
                                         har_path: str = "") -> dict:
    """Navigate to URL, capture all network traffic, and return API endpoints.

    Records a HAR file of all HTTP requests made during page load.
    Useful for discovering hidden API endpoints, leaked tokens in headers,
    and CORS misconfigurations.

    Returns: {requests, api_endpoints, har_path, auth_headers_found}
    """
    try:
        validate_scope(url, scope_rules)
    except ScopeViolationError as e:
        return {"error": str(e)}

    if not await is_available():
        return {"error": "agent-browser not installed"}

    if not har_path:
        har_path = f"/tmp/bm_har_{uuid.uuid4().hex[:8]}.har"

    session = new_session_id("netcap")
    try:
        await ab_network_har_start(session)
        await ab_open(url, session, wait_networkidle=True)
        await ab_network_har_stop(har_path, session)

        # Get XHR/fetch requests for API endpoint discovery
        xhr_requests = await ab_network_requests(session, req_type="xhr,fetch")

        api_endpoints: list[str] = []
        auth_headers_found: list[dict] = []

        for req in xhr_requests:
            req_url = req.get("url", "")
            if req_url:
                api_endpoints.append(req_url)
            # Check for auth headers in requests
            headers = req.get("headers", {})
            for header_name, header_val in (headers.items() if isinstance(headers, dict) else []):
                hn = header_name.lower()
                if hn in ("authorization", "x-api-key", "x-auth-token"):
                    auth_headers_found.append({
                        "url":    req_url,
                        "header": header_name,
                        "value":  str(header_val)[:40] + "...",
                    })

        return {
            "requests":          xhr_requests,
            "api_endpoints":     list(dict.fromkeys(api_endpoints)),  # dedupe
            "har_path":          har_path,
            "auth_headers_found": auth_headers_found,
        }
    except Exception as e:
        return {"error": str(e)}
    finally:
        await ab_close(session)

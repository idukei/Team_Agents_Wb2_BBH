# agent-browser Integration — BountyMind

## Qué es agent-browser

[agent-browser](https://agent-browser.dev) es un CLI de automatización de navegador construido en Rust, diseñado específicamente para agentes de IA.

Características principales:

- **Token-eficiente**: retorna un *accessibility tree* con refs (`@e1`, `@e2`) — 200-400 tokens en lugar de 3000-5000 de HTML crudo
- **Daemon persistente**: arquitectura cliente-daemon via Chrome DevTools Protocol (CDP), el daemon persiste entre comandos
- **Sesiones aisladas**: `--session <nombre>` crea instancias de navegador completamente independientes — ideal para agentes paralelos
- **50+ comandos**: navegación, forms, screenshots, red, storage, diálogos, JS eval, grabación de video

### Instalación

```bash
npm install -g agent-browser
agent-browser install          # descarga Chrome
```

### Variable de entorno

```
AGENT_BROWSER_BIN=agent-browser   # o ruta absoluta si no está en PATH
```

---

## Arquitectura de la integración

```
browser_scrape(url)                        ← vercel_browser.py
    │
    ├── [Tier 0] agent-browser             ← _try_agent_browser()
    │       • networkidle wait
    │       • bloqueo de recursos pesados
    │       • cookies reales con atributos
    │       • accessibility tree compacto
    │
    ├── [Tier 1] Playwright                ← _try_playwright()  (fallback)
    │
    └── [Tier 2] HTTPX                     ← _httpx_fallback()  (fallback final)


WebTester._run_web_technique(technique)    ← web_tester.py
    │
    ├── xss / xss_reflected
    │       ├── Layer 1: _test_xss()           HTTPX — reflected en respuesta HTTP
    │       └── Layer 2: _test_dom_xss()       agent-browser — dialog status (JS execution)
    │
    ├── open_redirect
    │       ├── Layer 1: _test_open_redirect() HTTPX — 3xx Location header
    │       └── Layer 2: _test_js_open_redirect() agent-browser — get url tras JS
    │
    ├── storage_exposure / localstorage_scan
    │       └── _test_storage_exposure()       agent-browser — storage + cookie audit
    │
    └── [cualquier técnica confirmada]
            └── _attach_screenshot_evidence()  agent-browser — screenshot anotado


ToolRegistry                               ← tools/registry.py
    ├── agent_browser_navigate             → snapshot compacto de cualquier URL
    ├── agent_browser_screenshot           → screenshot anotado como evidencia
    ├── agent_browser_storage_scan         → scan de storage + cookies
    └── agent_browser_network_capture      → captura HAR + endpoints API
```

---

## Comandos utilizados

### En `vercel_browser.py` — Tier 0 recon

| Comando | Función Python | Para qué |
|---|---|---|
| `network route *.{png,jpg...} --abort` | `ab_network_route_abort()` | Bloquear imágenes/fonts/CSS para recon más rápido |
| `open <url> --session` | `ab_open()` | Navegar a la URL en sesión aislada |
| `wait --load networkidle` | dentro de `ab_open()` | Esperar que el JS termine de cargar (SPAs, dApps) |
| `snapshot --session` | `ab_snapshot()` | Obtener accessibility tree |
| `cookies --session` | `ab_cookies()` | Extraer cookies con atributos httpOnly/secure/sameSite |
| `close --session` | `ab_close()` | Liberar sesión |

### En `web_tester.py` — DOM XSS

| Comando | Función Python | Para qué |
|---|---|---|
| `open` + `wait networkidle` | `ab_open()` | Cargar página con JS ejecutado |
| `snapshot` | `ab_snapshot()` | Obtener inputs disponibles |
| `fill <ref> <payload>` | `ab_fill()` | Inyectar payload XSS en input |
| `press Enter` | `ab_press()` | Disparar handlers onChange/onSubmit |
| `dialog status` | `ab_dialog_status()` | **Confirmar que alert() se ejecutó — única prueba fiable de DOM XSS** |
| `dialog accept` | `ab_dialog_accept()` | Cerrar el diálogo tras confirmación |

### En `web_tester.py` — JS Open Redirect

| Comando | Función Python | Para qué |
|---|---|---|
| `open <url?param=evil>` | `ab_open()` | Navegar con parámetro de redirect |
| `get url` | `ab_get_url()` | Leer URL final tras JS (window.location redirect) |

### En `agent_browser_tool.py` — Storage Scan

| Comando | Función Python | Para qué |
|---|---|---|
| `storage local` | `ab_storage_local()` | Leer todo localStorage |
| `storage session` | `ab_storage_session()` | Leer todo sessionStorage |
| `cookies` | `ab_cookies()` | Cookies con atributos de seguridad |
| `eval <js>` | `ab_eval()` | Extraer variables globales con nombres sospechosos |

### En `agent_browser_tool.py` — Network Capture

| Comando | Función Python | Para qué |
|---|---|---|
| `network har start` | `ab_network_har_start()` | Iniciar grabación HAR |
| `network har stop <path>` | `ab_network_har_stop()` | Guardar HAR con todo el tráfico |
| `network requests --type xhr,fetch` | `ab_network_requests()` | Filtrar requests XHR/fetch |

### En `web_tester.py` — Evidencia

| Comando | Función Python | Para qué |
|---|---|---|
| `screenshot <path> --full --annotate` | `ab_screenshot()` | Screenshot de página completa con elementos numerados |

---

## Funciones de bajo nivel disponibles (`agent_browser_tool.py`)

Todas las primitivas están disponibles para uso directo desde cualquier agente:

```python
from bountymind.tools.web.agent_browser_tool import (
    # Sesiones
    new_session_id,        # genera ID único: "prefix_a1b2c3d4"
    is_available,          # comprueba si el CLI está instalado (con cache)

    # Navegación
    ab_open,               # open URL + wait networkidle + snapshot
    ab_back, ab_forward, ab_reload,
    ab_get_url,            # URL final tras redirecciones JS
    ab_get_title,
    ab_get_text,           # texto de un elemento por ref
    ab_get_attr,           # atributo de un elemento por ref
    ab_is_visible,

    # Snapshot
    ab_snapshot,           # accessibility tree actual

    # Interacción
    ab_click,              # click por ref (@e3)
    ab_fill,               # clear + fill por ref
    ab_type,               # type sin clear
    ab_press,              # tecla: "Enter", "Tab", "Control+a"
    ab_hover, ab_select,

    # Localizadores semánticos (más robustos que refs)
    ab_find_label,         # por label visible: ab_find_label("Email", "fill", s, "x@y.com")
    ab_find_placeholder,   # por placeholder
    ab_find_role,          # por ARIA role: ab_find_role("button", "click", s, name="Submit")
    ab_find_text,          # por texto visible

    # Espera
    ab_wait_text,          # esperar texto en página
    ab_wait_url,           # esperar patrón en URL
    ab_wait_selector,      # esperar elemento

    # Diálogos (clave para XSS)
    ab_dialog_status,      # "open: alert(1)" | "none"
    ab_dialog_accept,      # aceptar (con texto opcional para prompts)
    ab_dialog_dismiss,     # descartar

    # JavaScript
    ab_eval,               # ejecutar JS: await ab_eval("document.cookie", session)

    # Storage
    ab_cookies,            # lista de cookies con atributos
    ab_storage_local,      # dict de localStorage
    ab_storage_session,    # dict de sessionStorage

    # Red
    ab_network_route_abort,   # bloquear recursos por patrón glob
    ab_network_unroute,
    ab_network_har_start,
    ab_network_har_stop,
    ab_network_requests,      # requests filtrados por tipo/método/status

    # Screenshots y grabación
    ab_screenshot,         # path, full_page=True, annotate=True
    ab_record_start,       # grabar video WebM
    ab_record_stop,

    # Consola / errores
    ab_console,            # mensajes de console.log
    ab_errors,             # errores JS de la página

    # Lifecycle
    ab_close,

    # Parsing de snapshots
    parse_refs,            # [{"ref": "@e1", "text": "Search input"}]
    find_input_refs,       # filtra refs que parecen inputs de texto
    find_link_refs,        # filtra refs que parecen links

    # Detección de secrets
    scan_for_secrets,      # detecta JWT, API keys, AWS keys, etc. en strings/dicts
)
```

---

## Tools disponibles en ToolRegistry

Los agentes pueden referenciar estas tools en su `loadout.tools`:

| Nombre | Descripción |
|---|---|
| `agent_browser_navigate` | Navegar a URL, retornar accessibility tree (~200-400 tokens). Ideal para SPAs/dApps JS-rendered. |
| `agent_browser_screenshot` | Navegar y guardar screenshot anotado. Para evidencia de bugs confirmados. |
| `agent_browser_storage_scan` | Scan de localStorage, sessionStorage, cookies y globals JS. Detecta JWT, API keys, flags inseguros. |
| `agent_browser_network_capture` | Capturar tráfico XHR/fetch como HAR. Descubre endpoints API ocultos y tokens en headers. |

Ejemplo de uso en un loadout:
```python
AgentLoadOut(
    agent_id="WebTester",
    tools=["agent_browser_navigate", "agent_browser_storage_scan", "xss_reflected"],
    tool_configs={
        "agent_browser_storage_scan": {"scope_rules": {...}},
    },
    ...
)
```

---

## Técnicas de detección nuevas

### DOM XSS — `_test_dom_xss()`

HTTPX no puede detectar DOM XSS porque el payload se ejecuta en el motor JS del navegador, no en la respuesta HTTP. El método usa `dialog status` para confirmación definitiva:

```
Payload inyectado en input → press Enter → dialog status == "open: ..."
                                                    ↑
                                         alert() ejecutado = XSS confirmado
```

Esto elimina falsos negativos en:
- Aplicaciones React/Vue/Angular con sanitización parcial
- Inputs que pasan el valor a `eval()`, `innerHTML`, o `document.write()`
- Template engines del lado del cliente

### JS Open Redirect — `_test_js_open_redirect()`

Algunos apps usan `window.location = params.redirect` en lugar de headers HTTP. HTTPX con `follow_redirects=False` no los detecta. agent-browser navega completamente y `get url` retorna la URL final tras ejecutar todo el JS.

### Storage Exposure — `_test_storage_exposure()`

Especialmente relevante para aplicaciones DeFi/Web3 que almacenan:
- Private keys o mnemonics en localStorage
- JWT tokens sin expiración
- API keys de servicios de terceros
- Cookies sin `HttpOnly` (accesibles vía `document.cookie` si hay XSS)

Patterns detectados: JWT (`eyJ...`), AWS keys (`AKIA...`), Stripe keys, API keys, passwords, tokens genéricos.

---

## Gestión de sesiones

Cada operación crea su propia sesión aislada:

| Prefijo | Contexto |
|---|---|
| `bm_recon_*` | browser_scrape — surface mapping |
| `bm_domxss_*` | DOM XSS testing |
| `bm_jsredir_*` | JS redirect testing |
| `bm_storage_*` | Storage scan |
| `bm_netcap_*` | Network capture |
| `bm_evidence_*` | Screenshot de evidencia |
| `bm_nav_*` | agent_browser_navigate tool |
| `bm_ss_*` | agent_browser_screenshot tool |

Los agentes Step B que corren en paralelo (vuln_researcher, creative_thinker, threat_modeler, formal_verifier) tienen sesiones completamente independientes — no hay colisiones de estado.

---

## Verificación

```bash
# 1. Verificar instalación
agent-browser --version

# 2. Smoke test desde Python
python -c "
import asyncio
from bountymind.tools.web.agent_browser_tool import is_available, agent_browser_navigate
print('available:', asyncio.run(is_available()))
result = asyncio.run(agent_browser_navigate('https://example.com', {}))
print('snapshot tokens ~', len(result.get('snapshot','').split()))
"

# 3. Test storage scan
python -c "
import asyncio
from bountymind.tools.web.agent_browser_tool import agent_browser_storage_scan
r = asyncio.run(agent_browser_storage_scan('https://app.example.com', {}))
print('secrets:', r.get('secrets_found'))
print('cookie_issues:', r.get('cookie_issues'))
"

# 4. Test fallback (sin agent-browser instalado)
AGENT_BROWSER_BIN=nonexistent python -c "
import asyncio
from bountymind.tools.web.agent_browser_tool import is_available
print('available:', asyncio.run(is_available()))  # debe retornar False
# vercel_browser.py debe caer a Playwright automáticamente
"
```
